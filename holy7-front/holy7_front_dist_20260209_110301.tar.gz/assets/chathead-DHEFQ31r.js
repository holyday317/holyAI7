const s="/holy7-front/assets/chathead-BuMqNnJD.gif";export{s as _};
